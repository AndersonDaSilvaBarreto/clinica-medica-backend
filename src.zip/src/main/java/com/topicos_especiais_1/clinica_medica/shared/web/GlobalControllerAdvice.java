package com.topicos_especiais_1.clinica_medica.shared.web;

import com.topicos_especiais_1.clinica_medica.notificacoes.domain.exception.NotificacaoException;
import com.topicos_especiais_1.clinica_medica.pagamentos.domain.exception.PagamentoException;
import com.topicos_especiais_1.clinica_medica.shared.api.ErroResponse;
import com.topicos_especiais_1.clinica_medica.shared.domain.exception.*;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.authorization.AuthorizationDeniedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.nio.file.AccessDeniedException;
import java.util.List;

@RestControllerAdvice
@Slf4j
public class GlobalControllerAdvice {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErroResponse> handleValidacao(
            MethodArgumentNotValidException exception,
            HttpServletRequest request
    ) {
        List<ErroResponse.ErroDetalhe> erros = exception.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(fieldError -> new ErroResponse.ErroDetalhe(
                        fieldError.getField(),
                        fieldError.getDefaultMessage()
                )
                ).toList();
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(ErroResponse.ofValidacao(request.getRequestURI(),erros));
    }

    @ExceptionHandler({
        org.springframework.security.authentication.InternalAuthenticationServiceException.class,
        org.springframework.security.authentication.BadCredentialsException.class
    })
    public ResponseEntity<ErroResponse> handleFalhaAutenticacaoLogin(Exception ex, HttpServletRequest request) {
        HttpStatus status = HttpStatus.UNAUTHORIZED; // Transforma em 401
        return ResponseEntity
                .status(status)
                .body(ErroResponse.of("E-mail ou senha incorretos.", status, request.getRequestURI()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErroResponse> handleGenerico(
            Exception ex,
            HttpServletRequest request) {

        log.error("Erro inesperado: ", ex);

        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ErroResponse.of(
                        "Erro interno do servidor",
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        request.getRequestURI())
                );
    }

    @ExceptionHandler(FormatoEmailInvalidoException.class)
    public ResponseEntity<ErroResponse> handleEmailInvalido(
            FormatoEmailInvalidoException ex,
            HttpServletRequest request) {

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(ErroResponse.of(ex.getMessage(), HttpStatus.BAD_REQUEST, request.getRequestURI()));
    }

    @ExceptionHandler(EntidadeNaoEncontradaException.class)
    public ResponseEntity<ErroResponse> handleEntidadeNaoEncontrada(
            EntidadeNaoEncontradaException ex,
            HttpServletRequest request
    ) {
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(ErroResponse.of(ex.getMessage(), HttpStatus.BAD_REQUEST,request.getRequestURI()));
    }
    @ExceptionHandler(InsufficientAuthenticationException.class)
    public ResponseEntity<ErroResponse> handleNaoAutenticado(
            InsufficientAuthenticationException ex,
            HttpServletRequest request) {

        return ResponseEntity
                .status(HttpStatus.UNAUTHORIZED)
                .body(ErroResponse.of("Não autenticado", HttpStatus.UNAUTHORIZED, request.getRequestURI()));
    }
    @ExceptionHandler(AuthorizationDeniedException.class)
    public ResponseEntity<ErroResponse> handleAcessoNaoAutorizado(
            AuthorizationDeniedException ex,
            HttpServletRequest request
    ) {
        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(ErroResponse.of("Não autorizado", HttpStatus.FORBIDDEN, request.getRequestURI()));
    }
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ErroResponse> handleSemPermissao(
            AccessDeniedException ex,
            HttpServletRequest request) {

        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(ErroResponse.of("Acesso negado", HttpStatus.FORBIDDEN, request.getRequestURI()));
    }
    @ExceptionHandler(FormatoNomeInvalidoException.class)
    public ResponseEntity<ErroResponse> handleNome(
            FormatoNomeInvalidoException ex,
            HttpServletRequest request
    ) {
        return ResponseEntity
                .badRequest()
                .body(ErroResponse.of(ex.getMessage(), HttpStatus.BAD_REQUEST, request.getRequestURI()));
    }
    @ExceptionHandler(EntidadeExistenteException.class)
    public ResponseEntity<ErroResponse> handleEntidadeExistente(
            EntidadeExistenteException ex,
            HttpServletRequest request
    ) {
        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body(ErroResponse.of(
                        ex.getMessage(), HttpStatus.CONFLICT, request.getRequestURI()
                ));

    }
    @ExceptionHandler(AcessoNegadoException.class)
    public ResponseEntity<ErroResponse> handleAcessoNegado(
            AcessoNegadoException ex,
            HttpServletRequest request) {

        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(ErroResponse.of(
                        ex.getMessage(), HttpStatus.FORBIDDEN,request.getRequestURI()
                        )
                );
    }
    @ExceptionHandler(FormatoInvalidoException.class)
    public ResponseEntity<ErroResponse> handleFormatoInvalido(
            FormatoInvalidoException ex,
            HttpServletRequest request
    ){
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(ErroResponse.of(ex.getMessage(),HttpStatus.BAD_REQUEST,request.getRequestURI()));
    }
    @ExceptionHandler(ConflitoException.class)
    public ResponseEntity<ErroResponse> handleConflito(
            ConflitoException ex,
            HttpServletRequest request
    ) {
        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body(ErroResponse.of(ex.getMessage(),HttpStatus.CONFLICT,request.getRequestURI()));
    }
    @ExceptionHandler(PagamentoException.class)
    public ResponseEntity<ErroResponse> handlePagamento(
            PagamentoException ex,
            HttpServletRequest request
    ) {
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(ErroResponse.of(ex.getMessage(), HttpStatus.BAD_REQUEST, request.getRequestURI()));
    }
    @ExceptionHandler(NotificacaoException.class)
    public ResponseEntity<ErroResponse> handleNotificacao(
            NotificacaoException ex,
            HttpServletRequest request
    ) {
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(ErroResponse.of(ex.getMessage(), HttpStatus.NOT_FOUND, request.getRequestURI()));
    }
}

